<?php

/**
 * Temperature service
 *
 * An unfinished temperature service example class
 */
class TemperatureService
{
    /**
     * Get the temperature at a specific time
     *
     * @param string $time The time hh:mm
     *
     * @return int
     */
    public function getTemperature(string $time)
    {

        // ...

    }
}
