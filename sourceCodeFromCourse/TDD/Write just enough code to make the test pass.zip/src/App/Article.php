<?php

namespace App;

class Article {

    public $title;
    
    public function getSlug()
    {
        return "";
    }    
}