<?php

namespace App;

class Article
{
    public $title;
}