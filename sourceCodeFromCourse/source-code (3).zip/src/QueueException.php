<?php

class QueueException extends Exception
{
}